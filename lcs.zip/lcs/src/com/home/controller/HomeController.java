package com.home.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dao.LcsDao;

@Controller
public class HomeController {
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		return "home";
	}
	
	@RequestMapping(value = "/result", method = RequestMethod.POST, produces = "application/json")
	public String lcsString(LcsDao lcsDao, Model model) {
		String str1 = lcsDao.getStr1();
		String str2 = lcsDao.getStr2();

		int str1Len = str1.length();
		int str2Len = str2.length();
		
		int[][] LCSuff = new int[str1Len + 1][str2Len + 1];
		int len = 0;
		int row = 0, col = 0;
		for (int i = 0; i <= str1Len; i++) {
			for (int j = 0; j <= str2Len; j++) {
				if (i == 0 || j == 0)
					LCSuff[i][j] = 0;

				else if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
					LCSuff[i][j] = LCSuff[i - 1][j - 1] + 1;
					if (len < LCSuff[i][j]) {
						len = LCSuff[i][j];
						row = i;
						col = j;
					}
				}
				else
					LCSuff[i][j] = 0;
			}
		}

		if (len == 0) {
			model.addAttribute("string", "No LCS" );
			return "lcs";
		}

		String resultStr = "";
		while (LCSuff[row][col] != 0) {
			resultStr = str1.charAt(row - 1) + resultStr;
			--len;

			row--;
			col--;
		}
		
		model.addAttribute("string", resultStr );
		return "lcs";
		
	}

}
